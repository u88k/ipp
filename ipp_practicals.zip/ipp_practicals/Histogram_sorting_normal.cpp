#include <iostream>

void histogram_sort(int* data, int n) {
    // Find the maximum value to determine the number of bins
    int max_val = 0;
    for (int i = 0; i < n; ++i) {
        if (data[i] > max_val) {
            max_val = data[i];
        }
    }
    
    // Number of bins (values range from 0 to max_val)
    int num_bins = max_val + 1;

    // Step 1: Initialize histogram array (one histogram for each bin)
    int* histogram = new int[num_bins](); // initialized to zero

    // Step 2: Compute local histograms
    {
        int* local_histogram = new int[num_bins](); // local histogram for each thread

        // loop to fill local histograms
        
        for (int i = 0; i < n; ++i) {
            local_histogram[data[i]]++;
        }

        // Step 3: Combine histograms from all threads
        
        {
            for (int i = 0; i < num_bins; ++i) {
                histogram[i] += local_histogram[i];
            }
        }

        delete[] local_histogram; // Clean up local histogram memory
    }

    // Step 4: Rebuild the sorted array based on the histogram
    int index = 0;
    for (int i = 0; i < num_bins; ++i) {
        for (int j = 0; j < histogram[i]; ++j) {
            data[index++] = i;
        }
    }

    delete[] histogram; // Clean up the histogram array
}

int main() {
    // Example data
    int data[] = {4, 2, 2, 8, 3, 3, 1, 7, 5, 9, 0, 6, 5, 3, 7};
    int n = sizeof(data) / sizeof(data[0]);

    // Print original data
    std::cout << "Original Data: ";
    for (int i = 0; i < n; ++i) {
        std::cout << data[i] << " ";
    }
    std::cout << std::endl;

    // Perform histogram sort
    histogram_sort(data, n);

    // Print sorted data
    std::cout << "Sorted Data: ";
    for (int i = 0; i < n; ++i) {
        std::cout << data[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}

