#include <iostream>
#include <cstdlib>
#include <omp.h> // Include OpenMP header

using namespace std;

int size1, size2, size3;

void print_mat(int **arr, int size){
	for(int i = 0; i < size; i++){
		for(int j = 0; j < size; j++){
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl << endl;
}
 
void matmul(int **arr1, int **arr2){
	if(size1 == size2){
		
		size3 = size1;
		int **arr3 = new int *[size3];
		for(int i = 0; i < size3; i++){
			arr3[i] = new int[size3];
			for(int j = 0; j < size3; j++)
				arr3[i][j] = 0; // Initialize to zero
		}

		// Parallelize outer loop using OpenMP
		#pragma omp parallel for collapse(2) shared(arr1, arr2, arr3)
		for(int i = 0; i < size1; i++){
			for(int j = 0; j < size2; j++){
				for(int k = 0; k < size3; k++){
					// Critical section not required here due to independent writes
					arr3[i][j] += arr1[i][k] * arr2[k][j];
				}
			}
		}
		
		print_mat(arr3, size3);
	}else{
		cout << "\nSize of the two matrices are not compatible for multiplication.\n";
		return;
	}
}

int main(){
	cout << "Enter the size of 1st square matrix: ";
	cin >> size1;
	
	int **arr1 = new int *[size1];
	for(int i = 0; i < size1; i++){
		arr1[i] = new int[size1];
	}
	
	for(int i = 0; i < size1; i++){
		for(int j = 0; j < size1; j++){
			arr1[i][j] = rand() % 10; // Smaller values for readability
		}
	}
	
	print_mat(arr1, size1);
	
	cout << "Enter the size of 2nd square matrix: ";
	cin >> size2;
	
	int **arr2 = new int *[size2];
	for(int i = 0; i < size2; i++){
		arr2[i] = new int[size2];
	}
	
	for(int i = 0; i < size2; i++){
		for(int j = 0; j < size2; j++){
			arr2[i][j] = rand() % 10;
		}
	}
	
	print_mat(arr2, size2);
	
	matmul(arr1, arr2);
	
	return 0;
}

